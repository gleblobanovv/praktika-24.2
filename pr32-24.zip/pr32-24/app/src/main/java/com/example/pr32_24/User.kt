package com.example.pr32_24

data class User(
    val username: String,
    val password: String
)